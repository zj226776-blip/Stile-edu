
import React, { useState, useEffect } from 'react';
import GameEmbed from './components/GameEmbed';
import AiAssistant from './components/AiAssistant';
import StileDisguise from './components/StileDisguise';
import { GameConfig } from './types';
import { downloadRepo } from './utils/repoCreator';

// Game Library Data
const GAMES: GameConfig[] = [
  {
    id: 'deltarune',
    title: "Deltarune (Scratch Edition)",
    url: "https://scratch.mit.edu/projects/1201842653/embed", 
    category: "RPG",
    description: "A fan-made recreation of the legendary RPG. Navigate the Dark World, dodge bullet patterns in fast-paced soul battles, and decide the fate of your enemies.",
    controls: "Arrow Keys to Move • Z to Interact/Select • X to Cancel/Menu",
    thumbnailUrl: "https://cdn2.scratch.mit.edu/get_image/project/1201842653_480x360.png"
  },
  {
    id: 'retro-bowl',
    title: "Game Hub",
    url: "https://retro-bowl-2.pages.dev/item?lesson=314",
    category: "Sports",
    description: "The glorious return of retro style football! Manage your NFL franchise, expand your roster, and take care of your press duties to keep your team and fans happy.",
    controls: "Mouse (Drag to Pass) • Click to Dive/Juke",
    thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400' style='background-color:black;'%3E%3Ctext x='290' y='230' font-family='Arial, Helvetica, sans-serif' font-weight='900' font-size='100' fill='white' text-anchor='end' letter-spacing='-4'%3EGame%3C/text%3E%3Crect x='305' y='145' width='190' height='120' rx='15' fill='%23ff9900' /%3E%3Ctext x='400' y='230' font-family='Arial, Helvetica, sans-serif' font-weight='900' font-size='100' fill='black' text-anchor='middle' letter-spacing='-4'%3Ehub%3C/text%3E%3C/svg%3E"
  },
  {
    id: 'pacman',
    title: "Pacman",
    url: "https://masonicgit.github.io/pacman/",
    category: "Arcade",
    description: "The timeless classic. Navigate the maze, eat all the pellets, avoid the ghosts (Blinky, Pinky, Inky, and Clyde), and chase the high score.",
    controls: "Arrow Keys to Move",
    thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='200' viewBox='0 0 600 200'%3E%3Crect width='600' height='200' rx='10' fill='%23ff9900' stroke='%23cc0000' stroke-width='15'/%3E%3Ctext x='300' y='140' font-family='Arial Black, Impact, sans-serif' font-weight='900' font-size='110' fill='%23ffff00' stroke='%23000000' stroke-width='6' text-anchor='middle' letter-spacing='2' style='filter: drop-shadow(5px 5px 0px rgba(0,0,0,0.5));'%3EPAC-MAN%3C/text%3E%3C/svg%3E"
  },
  {
    id: 'seraph',
    title: "Seraph",
    url: "https://mspoi.github.io/seraph/index.html",
    category: "Arcade",
    description: "A fast-paced rogue-like shooter. Play as a wizard, survive waves of enemies, and stack powerful upgrade cards to become unstoppable.",
    controls: "WASD to Move • Mouse to Aim & Shoot",
    thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400'%3E%3Cdefs%3E%3ClinearGradient id='grad1' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:%234b0082;stop-opacity:1' /%3E%3Cstop offset='100%25' style='stop-color:%23000000;stop-opacity:1' /%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='600' height='400' fill='url(%23grad1)' /%3E%3Ccircle cx='300' cy='200' r='80' fill='none' stroke='%2300ffff' stroke-width='4' /%3E%3Cpath d='M300 120 L300 280 M220 200 L380 200' stroke='%2300ffff' stroke-width='2' /%3E%3Ctext x='300' y='350' font-family='Courier New, monospace' font-weight='bold' font-size='40' fill='%2300ffff' text-anchor='middle' letter-spacing='5'%3ESERAPH%3C/text%3E%3C/svg%3E"
  },
  {
    id: 'ngon',
    title: "n-gon",
    url: "https://landgreen.github.io/n-gon/",
    category: "Arcade",
    description: "A fast-paced physics platformer. Wall-jump, slide, and shoot your way through procedurally generated levels as a polygon.",
    controls: "WASD/Arrows to Move • Mouse to Aim & Shoot",
    thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400'%3E%3Crect width='600' height='400' fill='%231a1a1a' /%3E%3Cpolygon points='300,80 490,190 420,380 180,380 110,190' fill='none' stroke='%23ff3333' stroke-width='15' /%3E%3Ctext x='300' y='240' font-family='Courier New, monospace' font-weight='bold' font-size='100' fill='white' text-anchor='middle'%3En-gon%3C/text%3E%3C/svg%3E"
  },
  {
    id: 'topvaz',
    title: "TopVAZ Games",
    url: "https://top-vaz-online.github.io/",
    category: "Arcade",
    description: "A massive collection of unblocked web games. Features classics like Basket Random, Pixel Shooter, and more.",
    controls: "Mouse to Browse • Various Controls",
    thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400'%3E%3Crect width='600' height='400' fill='%23111' /%3E%3Ctext x='50%25' y='50%25' font-family='Verdana' font-weight='bold' font-size='80' fill='white' text-anchor='middle' dy='.3em'%3ETOPVAZ%3C/text%3E%3Crect x='100' y='120' width='400' height='10' fill='%23e53935' /%3E%3C/svg%3E"
  }
];

const App: React.FC = () => {
  const [activeGame, setActiveGame] = useState<GameConfig | null>(null);
  const [isDisguised, setIsDisguised] = useState(true);

  // Toggle stealth mode class on body for scrollbar styling
  useEffect(() => {
    if (isDisguised) {
      document.body.classList.add('stealth-mode');
      document.title = "Log in - Stile";
    } else {
      document.body.classList.remove('stealth-mode');
      document.title = activeGame ? activeGame.title : "Arcade Nexus";
    }
  }, [isDisguised, activeGame]);

  if (isDisguised) {
    return <StileDisguise onUnlock={() => setIsDisguised(false)} />;
  }

  return (
    <div className="flex h-screen w-full bg-arcade-dark text-arcade-text font-sans overflow-hidden">
      {/* Sidebar Game List */}
      <div className="w-20 md:w-64 flex-shrink-0 bg-arcade-panel border-r border-white/10 flex flex-col z-20">
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <h1 className="text-xl font-bold text-arcade-neon tracking-tighter hidden md:block">
            NEXUS
          </h1>
          {/* Panic Button */}
          <button 
            onClick={() => setIsDisguised(true)}
            className="p-2 bg-red-500/20 text-red-400 rounded hover:bg-red-500/40 transition-colors"
            title="Panic Exit (Return to Stile)"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" />
            </svg>
          </button>
        </div>
        
        <div className="flex-grow overflow-y-auto p-2 space-y-2">
          {/* Home / Gallery Button */}
          <button
            onClick={() => setActiveGame(null)}
            className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all duration-200 ${
              !activeGame 
                ? 'bg-arcade-neon/20 text-arcade-neon shadow-[0_0_10px_rgba(0,243,255,0.1)]' 
                : 'hover:bg-white/5 text-gray-400 hover:text-white'
            }`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25a2.25 2.25 0 01-2.25-2.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z" />
            </svg>
            <span className="hidden md:block font-medium">Gallery</span>
          </button>

          <div className="h-px bg-white/10 my-2 mx-2" />

          {/* Game List */}
          {GAMES.map((game) => (
            <button
              key={game.id}
              onClick={() => setActiveGame(game)}
              className={`w-full flex items-center gap-3 p-3 rounded-lg text-left transition-all duration-200 group relative overflow-hidden ${
                activeGame?.id === game.id 
                  ? 'bg-arcade-neon text-black font-bold shadow-[0_0_15px_rgba(0,243,255,0.4)]' 
                  : 'hover:bg-white/10 text-gray-300 hover:text-white'
              }`}
            >
              {/* Active Indicator */}
              {activeGame?.id === game.id && (
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-white animate-pulse" />
              )}
              
              <div className="w-8 h-8 rounded bg-black/50 flex-shrink-0 overflow-hidden border border-white/10">
                {game.thumbnailUrl ? (
                   <img src={game.thumbnailUrl} alt="" className="w-full h-full object-cover" />
                ) : (
                   <div className="w-full h-full flex items-center justify-center text-[10px] text-white/50">IMG</div>
                )}
              </div>
              <div className="hidden md:block truncate">
                <div className="text-sm truncate">{game.title}</div>
                <div className={`text-[10px] uppercase tracking-wider ${activeGame?.id === game.id ? 'text-black/60' : 'text-white/30'}`}>
                  {game.category}
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Footer Actions */}
        <div className="p-3 border-t border-white/10 mt-auto">
          <button
            onClick={downloadRepo}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-white/5 hover:bg-white/10 text-xs text-gray-400 hover:text-white rounded transition-colors"
            title="Download source code for GitHub"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
            </svg>
            <span className="hidden md:inline">Download Source</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-grow flex flex-col relative z-10 bg-arcade-dark">
        {activeGame ? (
          <GameEmbed config={activeGame} />
        ) : (
          /* Game Gallery View */
          <div className="flex-grow overflow-y-auto p-6 md:p-10">
            <header className="mb-10">
              <h1 className="text-4xl md:text-5xl font-black text-white mb-2 tracking-tighter">
                ARCADE <span className="text-arcade-neon text-transparent bg-clip-text bg-gradient-to-r from-arcade-neon to-arcade-pink">NEXUS</span>
              </h1>
              <p className="text-white/50 text-lg">Select a protocol to initiate.</p>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {GAMES.map((game) => (
                <div 
                  key={game.id}
                  onClick={() => setActiveGame(game)}
                  className="group relative h-64 bg-arcade-panel rounded-xl overflow-hidden border border-white/5 hover:border-arcade-neon/50 transition-all duration-300 cursor-pointer hover:shadow-[0_0_30px_rgba(0,243,255,0.15)] transform hover:-translate-y-1"
                >
                  {/* Background Image/Thumbnail */}
                  {game.thumbnailUrl && (
                    <div className="absolute inset-0">
                      <img 
                        src={game.thumbnailUrl} 
                        alt={game.title} 
                        className="w-full h-full object-cover opacity-60 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-arcade-panel via-arcade-panel/80 to-transparent opacity-90 group-hover:opacity-60 transition-opacity duration-300" />
                    </div>
                  )}

                  <div className="absolute inset-0 p-6 flex flex-col justify-end">
                    <div className="transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                      <div className="flex items-center gap-2 mb-2">
                         <span className="px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest bg-arcade-neon/10 text-arcade-neon border border-arcade-neon/20 backdrop-blur-sm">
                          {game.category}
                        </span>
                      </div>
                      <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-arcade-neon transition-colors">
                        {game.title}
                      </h3>
                      <p className="text-sm text-gray-400 line-clamp-2 mb-4 group-hover:text-white transition-colors">
                        {game.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* AI Assistant Panel */}
      <AiAssistant activeGameTitle={activeGame?.title || 'Main Menu'} />
    </div>
  );
};

export default App;
