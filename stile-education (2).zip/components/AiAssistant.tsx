import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { streamGameTips } from '../services/geminiService';

interface AiAssistantProps {
  activeGameTitle: string;
}

const AiAssistant: React.FC<AiAssistantProps> = ({ activeGameTitle }) => {
  const [isOpen, setIsOpen] = useState(true);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: `Hello! I'm Gemini. I can help you with ${activeGameTitle} strategies or answer any other questions you have.`,
    }
  ]);
  
  // Track previous game title to reset/announce context switch
  const prevGameRef = useRef(activeGameTitle);

  useEffect(() => {
    if (prevGameRef.current !== activeGameTitle) {
      setMessages(prev => [
        ...prev,
        {
          id: Date.now().toString(),
          role: 'model',
          text: `✨ Context updated: Now focusing on ${activeGameTitle}.`
        }
      ]);
      prevGameRef.current = activeGameTitle;
    }
  }, [activeGameTitle]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    const history = messages.map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));

    try {
      // Pass the activeGameTitle to the service
      const stream = streamGameTips(history, userMsg.text, activeGameTitle);
      
      const modelMsgId = (Date.now() + 1).toString();
      setMessages(prev => [...prev, {
        id: modelMsgId,
        role: 'model',
        text: '',
        isStreaming: true
      }]);

      let fullText = '';
      for await (const chunk of stream) {
        fullText += chunk;
        setMessages(prev => prev.map(msg => 
          msg.id === modelMsgId ? { ...msg, text: fullText } : msg
        ));
      }

      setMessages(prev => prev.map(msg => 
        msg.id === modelMsgId ? { ...msg, isStreaming: false } : msg
      ));

    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={`
      flex flex-col bg-arcade-panel border-l border-white/10 transition-all duration-300 ease-in-out
      ${isOpen ? 'w-full md:w-80 lg:w-96' : 'w-12'}
      h-full relative
    `}>
      
      {/* Toggle Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="absolute -left-3 top-1/2 transform -translate-y-1/2 bg-blue-500 text-white p-1 rounded-full shadow-lg z-10 hover:bg-blue-400 transition-colors"
      >
        {isOpen ? (
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-4 h-4">
            <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
          </svg>
        ) : (
           <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-4 h-4">
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
          </svg>
        )}
      </button>

      {/* Collapsed State: Vertical Text */}
      {!isOpen && (
        <div className="h-full flex items-center justify-center cursor-pointer" onClick={() => setIsOpen(true)}>
          <span className="transform -rotate-90 whitespace-nowrap text-blue-400 font-bold tracking-widest text-sm">
            GEMINI
          </span>
        </div>
      )}

      {/* Expanded State: Chat Interface */}
      <div className={`flex flex-col h-full ${!isOpen ? 'hidden' : 'block'}`}>
        <div className="p-4 border-b border-white/10 bg-black/20">
          <h3 className="text-blue-400 font-bold text-lg flex items-center gap-2">
            {/* Gemini Sparkle Icon */}
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 animate-pulse">
                <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
            </svg>
            GEMINI
          </h3>
          <p className="text-xs text-white/50 truncate">Active Context: {activeGameTitle}</p>
        </div>

        <div className="flex-grow overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div 
                className={`
                  max-w-[85%] p-3 rounded-lg text-sm leading-relaxed
                  ${msg.role === 'user' 
                    ? 'bg-blue-600 text-white rounded-tr-none font-medium' 
                    : 'bg-white/10 text-gray-200 rounded-tl-none border border-white/5'
                  }
                `}
              >
                {msg.text}
                {msg.isStreaming && <span className="inline-block w-1.5 h-3 ml-1 bg-blue-400 animate-pulse"/>}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 bg-black/20 border-t border-white/10">
          <form onSubmit={handleSend} className="relative">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={`Ask Gemini...`}
              disabled={isLoading}
              className="w-full bg-black/50 border border-white/20 rounded-full py-2 pl-4 pr-10 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="absolute right-1 top-1/2 transform -translate-y-1/2 p-1.5 bg-blue-600 rounded-full text-white hover:bg-blue-500 disabled:opacity-50 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
                <path d="M3.105 2.289a.75.75 0 00-.826.95l1.414 4.925A1.5 1.5 0 005.135 9.25h6.115a.75.75 0 010 1.5H5.135a1.5 1.5 0 00-1.442 1.086l-1.414 4.926a.75.75 0 00.826.95 28.896 28.896 0 0015.293-7.154.75.75 0 000-1.115A28.897 28.897 0 003.105 2.289z" />
              </svg>
            </button>
          </form>
          <div className="flex gap-2 mt-2 justify-center">
            <button onClick={() => setInput("How do I play?")} className="text-[10px] px-2 py-1 bg-white/5 rounded hover:bg-white/10 text-gray-400">Controls?</button>
            <button onClick={() => setInput("Help me with my homework")} className="text-[10px] px-2 py-1 bg-white/5 rounded hover:bg-white/10 text-gray-400">Homework Help</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AiAssistant;