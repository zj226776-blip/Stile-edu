import React, { useRef, useState, useEffect } from 'react';
import { GameConfig } from '../types';

interface GameEmbedProps {
  config: GameConfig;
}

const GameEmbed: React.FC<GameEmbedProps> = ({ config }) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      const container = document.getElementById('game-container');
      if (container) {
        container.requestFullscreen().catch(err => {
          console.error(`Error attempting to enable fullscreen: ${err.message}`);
        });
      }
    } else {
      document.exitFullscreen();
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // Focus iframe on mount so keyboard controls work immediately
  useEffect(() => {
    if (iframeRef.current) {
      iframeRef.current.focus();
    }
  }, []);

  const handleRefocus = () => {
    if(iframeRef.current) {
      iframeRef.current.focus();
    }
  };

  return (
    <div 
      id="game-container" 
      className={`relative w-full h-full bg-black flex flex-col ${isFullscreen ? 'p-0' : 'rounded-lg border-2 border-arcade-panel shadow-[0_0_15px_rgba(0,243,255,0.2)]'}`}
    >
      {/* Header / Controls Bar (Hidden in Fullscreen) */}
      {!isFullscreen && (
        <div className="flex justify-between items-center p-3 bg-arcade-panel border-b border-white/10">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></div>
            <h2 className="text-arcade-neon font-bold tracking-wider uppercase text-sm md:text-base">
              {config.title}
            </h2>
          </div>
          <div className="flex items-center space-x-2">
             <a 
              href={config.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-3 py-1 text-xs bg-arcade-neon/10 hover:bg-arcade-neon/30 text-arcade-neon border border-arcade-neon/20 rounded transition-colors"
              title="Open in new tab if game doesn't load"
            >
              Open External
            </a>
             <button 
              onClick={handleRefocus}
              className="px-3 py-1 text-xs bg-white/10 hover:bg-white/20 text-white rounded transition-colors"
              title="Click if controls aren't working"
            >
              Focus Game
            </button>
            <button 
              onClick={toggleFullscreen}
              className="p-1 hover:text-arcade-neon transition-colors"
              aria-label="Toggle Fullscreen"
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* The Game Iframe */}
      <div className="flex-grow relative overflow-hidden bg-black">
        <iframe
          ref={iframeRef}
          src={config.url}
          title={config.title}
          className="absolute top-0 left-0 w-full h-full border-0"
          allow="autoplay; fullscreen; gamepad; clipboard-read; clipboard-write"
          allowFullScreen
          // Sandbox Permissions:
          // allow-scripts: runs the game
          // allow-same-origin: needed for many HTML5 games to access own resources
          // allow-popups: Added back because some game engines fail to initialize audio/save data without it
          // allow-modals: allows alert() which some games use for pausing
          sandbox="allow-scripts allow-same-origin allow-forms allow-pointer-lock allow-presentation allow-modals allow-popups"
        />
      </div>
    </div>
  );
};

export default GameEmbed;