
import React, { useState } from 'react';

interface StileDisguiseProps {
  onUnlock: () => void;
}

const StileDisguise: React.FC<StileDisguiseProps> = ({ onUnlock }) => {
  const [email, setEmail] = useState('');

  const handleFakeAction = () => {
    // Fake behavior: Refresh the page to simulate a "glitch" or login loop
    // This keeps the disguise intact if someone who doesn't know the secret clicks it.
    window.location.reload();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleFakeAction();
  };

  // Lighter Green for Stile as requested
  const STILE_GREEN = "#00C985";

  return (
    <div className="min-h-screen bg-white flex flex-col font-sans text-[#172B4D]">
      
      {/* Navbar / Header */}
      <header className="px-8 py-6">
        <div 
          className={`font-bold text-3xl tracking-tighter select-none cursor-default`}
          style={{ color: STILE_GREEN }}
        >
          stile
        </div>
      </header>

      {/* Login Container */}
      <div className="flex-grow flex items-center justify-center p-4">
        <div className="w-full max-w-[480px]">
          
          <h1 className="text-4xl font-bold mb-3 text-[#172B4D]">Log in</h1>
          <p className="text-gray-600 mb-8 text-lg">
            Don't have an account? <span onClick={handleFakeAction} className="hover:underline cursor-pointer" style={{ color: STILE_GREEN }}>Sign up</span>
          </p>

          {/* Social Logins */}
          <div className="space-y-3 mb-8">
            <button type="button" onClick={handleFakeAction} className="w-full border border-gray-300 rounded-md py-2.5 px-4 flex items-center justify-center gap-3 hover:bg-gray-50 transition-colors font-medium text-gray-700">
               {/* Microsoft Logo SVG */}
               <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 23 23"><path fill="#f3f3f3" d="M0 0h23v23H0z"/><path fill="#f35325" d="M1 1h10v10H1z"/><path fill="#81bc06" d="M12 1h10v10H12z"/><path fill="#05a6f0" d="M1 12h10v10H1z"/><path fill="#ffba08" d="M12 12h10v10H12z"/></svg>
               Sign in with Microsoft
            </button>
            <button type="button" onClick={handleFakeAction} className="w-full border border-gray-300 rounded-md py-2.5 px-4 flex items-center justify-center gap-3 hover:bg-gray-50 transition-colors font-medium text-gray-700">
               {/* Google Logo SVG */}
               <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12c0-6.627 5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C12.955 4 4 12.955 4 24c0 11.045 8.955 20 20 20c11.045 0 20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"/><path fill="#FF3D00" d="m6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4c-7.865 0-14.739 4.316-18.232 10.691z"/><path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238C29.211 35.091 26.715 36 24 36c-5.202 0-9.619-3.317-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z"/><path fill="#1976D2" d="M43.611 20.083L43.595 20H24v8h11.303a12.04 12.04 0 0 1-4.087 5.571l.003-.002l6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z"/></svg>
               Sign in with Google
            </button>
          </div>

          <div className="relative mb-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500 font-medium">OR</span>
            </div>
          </div>

          {/* Email Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Email</label>
              <input 
                type="text" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`w-full px-4 py-3 rounded border border-gray-300 focus:ring-1 outline-none transition-colors text-lg`}
                // Inline styles for colors that need to match the variable exactly
                style={{ 
                  '--tw-ring-color': STILE_GREEN, 
                  '--tw-border-opacity': 1,
                  borderColor: email ? STILE_GREEN : undefined 
                } as React.CSSProperties}
                placeholder=""
                autoFocus
              />
            </div>
            
            <div className="flex justify-end">
               <button 
                 type="submit" 
                 className="hover:brightness-90 text-white font-bold py-3 px-6 rounded transition-all flex items-center gap-2"
                 style={{ backgroundColor: STILE_GREEN }}
               >
                 Next
                 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={3} stroke="currentColor" className="w-4 h-4">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                </svg>
               </button>
            </div>
          </form>

        </div>
      </div>

      {/* Footer */}
      <footer className="py-8 text-center text-sm text-gray-500">
         <span 
          onClick={onUnlock} 
          className="mr-6 hover:underline cursor-pointer"
          title="Privacy Policy"
         >
            Privacy Policy
         </span>
         <span 
          onClick={handleFakeAction} 
          className="hover:underline cursor-pointer"
        >
           Terms & Conditions
        </span>
      </footer>

    </div>
  );
};

export default StileDisguise;
