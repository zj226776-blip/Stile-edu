
export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  isStreaming?: boolean;
}

export interface GameConfig {
  id: string;
  title: string;
  url: string;
  description: string;
  category: 'Platformer' | 'Arcade' | 'Puzzle' | 'Strategy' | 'Endless' | 'RPG' | 'Racing' | 'Sports' | 'Entertainment';
  controls?: string;
  thumbnailUrl?: string;
}