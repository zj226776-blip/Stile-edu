
export const downloadApp = () => {
  // We explicitly escape backticks (`) and dollar signs ($) for the inner template string to ensure
  // they are preserved in the downloaded file's source code rather than evaluated here.
  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Log in - Stile</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
      tailwind.config = {
        theme: {
          extend: {
            colors: {
              arcade: { dark: '#0f0f1a', panel: '#1a1a2e', neon: '#00f3ff', pink: '#ff00ff', text: '#eaeaea' },
              stile: { green: '#00C985', text: '#172B4D' }
            },
            fontFamily: {
              sans: ['-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'sans-serif'],
            }
          }
        }
      }
    </script>
    <style>
      body { background-color: #0f0f1a; color: #eaeaea; overflow: hidden; }
      ::-webkit-scrollbar { width: 8px; height: 8px; }
      ::-webkit-scrollbar-track { background: #1a1a2e; }
      ::-webkit-scrollbar-thumb { background: #33334d; border-radius: 4px; }
      ::-webkit-scrollbar-thumb:hover { background: #00f3ff; }
      body.stealth-mode { background-color: #ffffff; color: #172B4D; }
      body.stealth-mode ::-webkit-scrollbar-track { background: #eee; }
      body.stealth-mode ::-webkit-scrollbar-thumb { background: #ccc; }
      #error-log { display: none; position: fixed; top: 0; left: 0; right: 0; background: #ffebee; color: #c62828; padding: 20px; z-index: 9999; border-bottom: 2px solid #ef5350; font-family: monospace; }
    </style>
    <!-- Import Map for React and GenAI -->
    <script type="importmap">
    {
      "imports": {
        "react": "https://esm.sh/react@18.2.0",
        "react-dom/client": "https://esm.sh/react-dom@18.2.0/client",
        "@google/genai": "https://esm.sh/@google/genai@0.1.1"
      }
    }
    </script>
    <!-- Babel for in-browser JSX compilation -->
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body>
    <div id="error-log"></div>
    <div id="root"></div>

    <script>
      window.onerror = function(msg, url, line, col, error) {
        var el = document.getElementById('error-log');
        el.style.display = 'block';
        el.innerHTML = '<strong>System Error:</strong> ' + msg + '<br/><small>' + (error ? error.stack : '') + '</small>';
      };
    </script>

    <!-- IMPORTANT: data-type="module" is required for imports to work in Babel Standalone -->
    <script type="text/babel" data-presets="react,typescript" data-type="module">
      import React, { useState, useEffect, useRef } from 'react';
      import ReactDOM from 'react-dom/client';
      import { GoogleGenAI } from "@google/genai";

      // --- CONFIG ---
      const API_KEY = "${process.env.API_KEY || ''}"; 
      const GAMES = [
        {
          id: 'deltarune',
          title: "Deltarune (Scratch Edition)",
          url: "https://scratch.mit.edu/projects/1201842653/embed", 
          category: "RPG",
          description: "A fan-made recreation of the legendary RPG. Navigate the Dark World, dodge bullet patterns in fast-paced soul battles, and decide the fate of your enemies.",
          controls: "Arrow Keys to Move • Z to Interact/Select • X to Cancel/Menu",
          thumbnailUrl: "https://cdn2.scratch.mit.edu/get_image/project/1201842653_480x360.png"
        },
        {
          id: 'retro-bowl',
          title: "Game Hub",
          url: "https://retro-bowl-2.pages.dev/item?lesson=314",
          category: "Sports",
          description: "The glorious return of retro style football! Manage your NFL franchise, expand your roster, and take care of your press duties to keep your team and fans happy.",
          controls: "Mouse (Drag to Pass) • Click to Dive/Juke",
          thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400' style='background-color:black;'%3E%3Ctext x='290' y='230' font-family='Arial, Helvetica, sans-serif' font-weight='900' font-size='100' fill='white' text-anchor='end' letter-spacing='-4'%3EGame%3C/text%3E%3Crect x='305' y='145' width='190' height='120' rx='15' fill='%23ff9900' /%3E%3Ctext x='400' y='230' font-family='Arial, Helvetica, sans-serif' font-weight='900' font-size='100' fill='black' text-anchor='middle' letter-spacing='-4'%3Ehub%3C/text%3E%3C/svg%3E"
        },
        {
          id: 'pacman',
          title: "Pacman",
          url: "https://masonicgit.github.io/pacman/",
          category: "Arcade",
          description: "The timeless classic. Navigate the maze, eat all the pellets, avoid the ghosts (Blinky, Pinky, Inky, and Clyde), and chase the high score.",
          controls: "Arrow Keys to Move",
          thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='200' viewBox='0 0 600 200'%3E%3Crect width='600' height='200' rx='10' fill='%23ff9900' stroke='%23cc0000' stroke-width='15'/%3E%3Ctext x='300' y='140' font-family='Arial Black, Impact, sans-serif' font-weight='900' font-size='110' fill='%23ffff00' stroke='%23000000' stroke-width='6' text-anchor='middle' letter-spacing='2' style='filter: drop-shadow(5px 5px 0px rgba(0,0,0,0.5));'%3EPAC-MAN%3C/text%3E%3C/svg%3E"
        },
        {
          id: 'seraph',
          title: "Seraph",
          url: "https://mspoi.github.io/seraph/index.html",
          category: "Arcade",
          description: "A fast-paced rogue-like shooter. Play as a wizard, survive waves of enemies, and stack powerful upgrade cards to become unstoppable.",
          controls: "WASD to Move • Mouse to Aim & Shoot",
          thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400'%3E%3Cdefs%3E%3ClinearGradient id='grad1' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:%234b0082;stop-opacity:1' /%3E%3Cstop offset='100%25' style='stop-color:%23000000;stop-opacity:1' /%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='600' height='400' fill='url(%23grad1)' /%3E%3Ccircle cx='300' cy='200' r='80' fill='none' stroke='%2300ffff' stroke-width='4' /%3E%3Cpath d='M300 120 L300 280 M220 200 L380 200' stroke='%2300ffff' stroke-width='2' /%3E%3Ctext x='300' y='350' font-family='Courier New, monospace' font-weight='bold' font-size='40' fill='%2300ffff' text-anchor='middle' letter-spacing='5'%3ESERAPH%3C/text%3E%3C/svg%3E"
        },
        {
          id: 'ngon',
          title: "n-gon",
          url: "https://landgreen.github.io/n-gon/",
          category: "Arcade",
          description: "A fast-paced physics platformer. Wall-jump, slide, and shoot your way through procedurally generated levels as a polygon.",
          controls: "WASD/Arrows to Move • Mouse to Aim & Shoot",
          thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400'%3E%3Crect width='600' height='400' fill='%231a1a1a' /%3E%3Cpolygon points='300,80 490,190 420,380 180,380 110,190' fill='none' stroke='%23ff3333' stroke-width='15' /%3E%3Ctext x='300' y='240' font-family='Courier New, monospace' font-weight='bold' font-size='100' fill='white' text-anchor='middle'%3En-gon%3C/text%3E%3C/svg%3E"
        },
        {
          id: 'topvaz',
          title: "TopVAZ Games",
          url: "https://top-vaz-online.github.io/",
          category: "Arcade",
          description: "A massive collection of unblocked web games. Features classics like Basket Random, Pixel Shooter, and more.",
          controls: "Mouse to Browse • Various Controls",
          thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400'%3E%3Crect width='600' height='400' fill='%23111' /%3E%3Ctext x='50%25' y='50%25' font-family='Verdana' font-weight='bold' font-size='80' fill='white' text-anchor='middle' dy='.3em'%3ETOPVAZ%3C/text%3E%3Crect x='100' y='120' width='400' height='10' fill='%23e53935' /%3E%3C/svg%3E"
        }
      ];

      // --- GEMINI SERVICE ---
      const streamGameTips = async function* (history, newMessage, gameTitle) {
        if (!API_KEY) { yield "API Key not found in download. AI unavailable."; return; }
        const ai = new GoogleGenAI({ apiKey: API_KEY });
        const systemInstruction = \`You are Gemini, a helpful AI assistant. User is playing: "\${gameTitle}". Context: School/Work disguised app. Tone: Friendly, concise. Provide game strategies or homework help.\`;
        
        try {
          const chat = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: { systemInstruction, thinkingConfig: { thinkingBudget: 0 } },
            history: history,
          });
          const result = await chat.sendMessageStream({ message: newMessage });
          for await (const chunk of result) { if (chunk.text) yield chunk.text; }
        } catch (error) {
          console.error("Gemini Error:", error);
          yield "⚠️ Connection interference. Try again.";
        }
      };

      // --- GAME EMBED ---
      const GameEmbed = ({ config }) => {
        const iframeRef = useRef(null);
        const [isFullscreen, setIsFullscreen] = useState(false);
        const toggleFullscreen = () => {
          if (!document.fullscreenElement) {
             document.getElementById('game-container')?.requestFullscreen();
          } else {
             document.exitFullscreen();
          }
        };
        useEffect(() => {
          const handle = () => setIsFullscreen(!!document.fullscreenElement);
          document.addEventListener('fullscreenchange', handle);
          return () => document.removeEventListener('fullscreenchange', handle);
        }, []);

        return (
          <div id="game-container" className={\`relative w-full h-full bg-black flex flex-col \${isFullscreen ? 'p-0' : 'rounded-lg border-2 border-arcade-panel shadow-[0_0_15px_rgba(0,243,255,0.2)]'}\`}>
            {!isFullscreen && (
              <div className="flex justify-between items-center p-3 bg-arcade-panel border-b border-white/10">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></div>
                  <h2 className="text-arcade-neon font-bold tracking-wider uppercase text-sm md:text-base">{config.title}</h2>
                </div>
                <div className="flex items-center space-x-2">
                   <a href={config.url} target="_blank" rel="noopener noreferrer" className="px-3 py-1 text-xs bg-arcade-neon/10 hover:bg-arcade-neon/30 text-arcade-neon border border-arcade-neon/20 rounded transition-colors">Open External</a>
                   <button onClick={toggleFullscreen} className="p-1 hover:text-arcade-neon transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15" /></svg>
                   </button>
                </div>
              </div>
            )}
            <div className="flex-grow relative overflow-hidden bg-black">
              <iframe
                ref={iframeRef}
                src={config.url}
                title={config.title}
                className="absolute top-0 left-0 w-full h-full border-0"
                allow="autoplay; fullscreen; gamepad; clipboard-read; clipboard-write"
                allowFullScreen
                sandbox="allow-scripts allow-same-origin allow-forms allow-pointer-lock allow-presentation allow-modals allow-popups"
              />
            </div>
          </div>
        );
      };

      // --- AI ASSISTANT ---
      const AiAssistant = ({ activeGameTitle }) => {
        const [isOpen, setIsOpen] = useState(true);
        const [input, setInput] = useState('');
        const [isLoading, setIsLoading] = useState(false);
        const [messages, setMessages] = useState([{ id: 'welcome', role: 'model', text: \`Hello! I'm Gemini. I can help with \${activeGameTitle}.\` }]);
        const prevGameRef = useRef(activeGameTitle);
        const messagesEndRef = useRef(null);

        useEffect(() => {
          if (prevGameRef.current !== activeGameTitle) {
            setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: \`✨ Context: \${activeGameTitle}\` }]);
            prevGameRef.current = activeGameTitle;
          }
        }, [activeGameTitle]);

        useEffect(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), [messages]);

        const handleSend = async (e) => {
          e?.preventDefault();
          if (!input.trim() || isLoading) return;
          const userMsg = { id: Date.now().toString(), role: 'user', text: input };
          setMessages(prev => [...prev, userMsg]);
          setInput('');
          setIsLoading(true);

          const history = messages.map(m => ({ role: m.role, parts: [{ text: m.text }] }));
          try {
            const stream = streamGameTips(history, userMsg.text, activeGameTitle);
            const modelMsgId = (Date.now() + 1).toString();
            setMessages(prev => [...prev, { id: modelMsgId, role: 'model', text: '', isStreaming: true }]);
            let fullText = '';
            for await (const chunk of stream) {
              fullText += chunk;
              setMessages(prev => prev.map(msg => msg.id === modelMsgId ? { ...msg, text: fullText } : msg));
            }
            setMessages(prev => prev.map(msg => msg.id === modelMsgId ? { ...msg, isStreaming: false } : msg));
          } catch (err) { console.error(err); } 
          finally { setIsLoading(false); }
        };

        return (
          <div className={\`flex flex-col bg-arcade-panel border-l border-white/10 transition-all duration-300 ease-in-out \${isOpen ? 'w-full md:w-80 lg:w-96' : 'w-12'} h-full relative\`}>
            <button onClick={() => setIsOpen(!isOpen)} className="absolute -left-3 top-1/2 transform -translate-y-1/2 bg-blue-500 text-white p-1 rounded-full shadow-lg z-10 hover:bg-blue-400">{isOpen ? '>' : '<'}</button>
            {!isOpen && <div className="h-full flex items-center justify-center cursor-pointer" onClick={() => setIsOpen(true)}><span className="transform -rotate-90 text-blue-400 font-bold tracking-widest text-sm">GEMINI</span></div>}
            <div className={\`flex flex-col h-full \${!isOpen ? 'hidden' : 'block'}\`}>
              <div className="p-4 border-b border-white/10 bg-black/20"><h3 className="text-blue-400 font-bold text-lg">GEMINI</h3><p className="text-xs text-white/50">{activeGameTitle}</p></div>
              <div className="flex-grow overflow-y-auto p-4 space-y-4">
                {messages.map((msg) => (
                  <div key={msg.id} className={\`flex \${msg.role === 'user' ? 'justify-end' : 'justify-start'}\`}>
                    <div className={\`max-w-[85%] p-3 rounded-lg text-sm \${msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-white/10 text-gray-200'}\`}>{msg.text}</div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
              <div className="p-4 bg-black/20 border-t border-white/10">
                <form onSubmit={handleSend} className="relative">
                  <input type="text" value={input} onChange={(e) => setInput(e.target.value)} disabled={isLoading} className="w-full bg-black/50 border border-white/20 rounded-full py-2 pl-4 pr-10 text-sm text-white" placeholder="Ask Gemini..." />
                </form>
              </div>
            </div>
          </div>
        );
      };

      // --- STILE DISGUISE ---
      const StileDisguise = ({ onUnlock }) => {
        const handleFakeAction = () => window.location.reload();
        const STILE_GREEN = "#00C985";
        return (
          <div className="min-h-screen bg-white flex flex-col font-sans text-[#172B4D]">
            <header className="px-8 py-6"><div className="font-bold text-3xl tracking-tighter" style={{ color: STILE_GREEN }}>stile</div></header>
            <div className="flex-grow flex items-center justify-center p-4">
              <div className="w-full max-w-[480px]">
                <h1 className="text-4xl font-bold mb-3 text-[#172B4D]">Log in</h1>
                <p className="text-gray-600 mb-8 text-lg">Don't have an account? <span onClick={handleFakeAction} className="hover:underline cursor-pointer" style={{ color: STILE_GREEN }}>Sign up</span></p>
                <div className="space-y-3 mb-8">
                  <button onClick={handleFakeAction} className="w-full border border-gray-300 rounded-md py-2.5 px-4 font-medium text-gray-700 hover:bg-gray-50">Sign in with Microsoft</button>
                  <button onClick={handleFakeAction} className="w-full border border-gray-300 rounded-md py-2.5 px-4 font-medium text-gray-700 hover:bg-gray-50">Sign in with Google</button>
                </div>
                <div className="relative mb-8"><div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-300"></div></div><div className="relative flex justify-center text-sm"><span className="px-2 bg-white text-gray-500">OR</span></div></div>
                <form onSubmit={(e) => {e.preventDefault(); handleFakeAction();}} className="space-y-5">
                  <div><label className="block text-sm font-bold text-gray-700 mb-1">Email</label><input type="text" style={{'--tw-ring-color': STILE_GREEN, borderColor: STILE_GREEN}} className="w-full px-4 py-3 rounded border focus:ring-1 outline-none transition-colors text-lg" /></div>
                  <div className="flex justify-end"><button type="submit" className="text-white font-bold py-3 px-6 rounded transition-all flex items-center gap-2" style={{ backgroundColor: STILE_GREEN }}>Next</button></div>
                </form>
              </div>
            </div>
            <footer className="py-8 text-center text-sm text-gray-500">
               <span onClick={onUnlock} className="mr-6 hover:underline cursor-pointer">Privacy Policy</span>
               <span onClick={handleFakeAction} className="hover:underline cursor-pointer">Terms & Conditions</span>
            </footer>
          </div>
        );
      };

      // --- APP ---
      const App = () => {
        const [activeGame, setActiveGame] = useState(null);
        const [isDisguised, setIsDisguised] = useState(true);

        useEffect(() => {
          if (isDisguised) {
            document.body.classList.add('stealth-mode');
            document.title = "Log in - Stile";
          } else {
            document.body.classList.remove('stealth-mode');
            document.title = activeGame ? activeGame.title : "Arcade Nexus";
          }
        }, [isDisguised, activeGame]);

        if (isDisguised) return <StileDisguise onUnlock={() => setIsDisguised(false)} />;

        return (
          <div className="flex h-screen w-full bg-arcade-dark text-arcade-text font-sans overflow-hidden">
            <div className="w-20 md:w-64 flex-shrink-0 bg-arcade-panel border-r border-white/10 flex flex-col z-20">
              <div className="p-4 border-b border-white/10 flex items-center justify-between">
                <h1 className="text-xl font-bold text-arcade-neon hidden md:block">NEXUS</h1>
                <button onClick={() => setIsDisguised(true)} className="p-2 bg-red-500/20 text-red-400 rounded hover:bg-red-500/40" title="Panic Exit">Panic</button>
              </div>
              <div className="flex-grow overflow-y-auto p-2 space-y-2">
                <button onClick={() => setActiveGame(null)} className={\`w-full flex items-center gap-3 p-3 rounded-lg \${!activeGame ? 'bg-arcade-neon/20 text-arcade-neon' : 'hover:bg-white/5 text-gray-400'}\`}>
                  <span className="hidden md:block font-medium">Gallery</span>
                </button>
                {GAMES.map((game) => (
                  <button key={game.id} onClick={() => setActiveGame(game)} className={\`w-full flex items-center gap-3 p-3 rounded-lg text-left \${activeGame?.id === game.id ? 'bg-arcade-neon text-black font-bold' : 'hover:bg-white/10 text-gray-300'}\`}>
                    <div className="hidden md:block truncate"><div className="text-sm">{game.title}</div><div className="text-[10px] uppercase">{game.category}</div></div>
                  </button>
                ))}
              </div>
            </div>
            <div className="flex-grow flex flex-col relative z-10 bg-arcade-dark">
              {activeGame ? <GameEmbed config={activeGame} /> : (
                <div className="flex-grow overflow-y-auto p-6 md:p-10">
                  <header className="mb-10"><h1 className="text-4xl md:text-5xl font-black text-white mb-2">ARCADE <span className="text-arcade-neon">NEXUS</span></h1></header>
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {GAMES.map((game) => (
                      <div key={game.id} onClick={() => setActiveGame(game)} className="group relative h-64 bg-arcade-panel rounded-xl overflow-hidden border border-white/5 hover:border-arcade-neon/50 cursor-pointer">
                        {game.thumbnailUrl && <img src={game.thumbnailUrl} className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity" />}
                        <div className="absolute inset-0 bg-gradient-to-t from-arcade-panel to-transparent opacity-90 group-hover:opacity-60" />
                        <div className="absolute inset-0 p-6 flex flex-col justify-end">
                          <h3 className="text-2xl font-bold text-white mb-2">{game.title}</h3>
                          <p className="text-sm text-gray-400 line-clamp-2">{game.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <AiAssistant activeGameTitle={activeGame?.title || 'Main Menu'} />
          </div>
        );
      };

      const root = ReactDOM.createRoot(document.getElementById('root'));
      root.render(<App />);
    </script>
</body>
</html>`;

  const blob = new Blob([htmlContent], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'index.html';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};
