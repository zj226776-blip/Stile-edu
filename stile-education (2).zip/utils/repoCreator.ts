import JSZip from 'jszip';

export const downloadRepo = async () => {
  const zip = new JSZip();

  // 1. Root Configuration Files
  zip.file("package.json", JSON.stringify({
    "name": "arcade-nexus",
    "private": true,
    "version": "1.0.0",
    "type": "module",
    "scripts": {
      "dev": "vite",
      "build": "tsc && vite build",
      "preview": "vite preview"
    },
    "dependencies": {
      "react": "^18.2.0",
      "react-dom": "^18.2.0",
      "@google/genai": "^0.1.1"
    },
    "devDependencies": {
      "@types/react": "^18.2.66",
      "@types/react-dom": "^18.2.22",
      "@vitejs/plugin-react": "^4.2.1",
      "typescript": "^5.2.2",
      "vite": "^5.2.0",
      "autoprefixer": "^10.4.19",
      "postcss": "^8.4.38",
      "tailwindcss": "^3.4.3"
    }
  }, null, 2));

  zip.file("vite.config.ts", `import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
})`);

  zip.file("tsconfig.json", JSON.stringify({
    "compilerOptions": {
      "target": "ES2020",
      "useDefineForClassFields": true,
      "lib": ["ES2020", "DOM", "DOM.Iterable"],
      "module": "ESNext",
      "skipLibCheck": true,
      "moduleResolution": "bundler",
      "allowImportingTsExtensions": true,
      "resolveJsonModule": true,
      "isolatedModules": true,
      "noEmit": true,
      "jsx": "react-jsx",
      "strict": true,
      "unusedLocals": false,
      "unusedParameters": false,
      "noFallthroughCasesInSwitch": true
    },
    "include": ["src"]
  }, null, 2));

  zip.file("tailwind.config.js", `/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        arcade: {
          dark: '#0f0f1a',
          panel: '#1a1a2e',
          neon: '#00f3ff',
          pink: '#ff00ff',
          text: '#eaeaea',
        },
        stile: {
          blue: '#0052CC',
          bg: '#F4F5F7',
          text: '#172B4D'
        }
      },
    },
  },
  plugins: [],
}`);

  zip.file("postcss.config.js", `export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}`);

  zip.file("README.md", `# Arcade Nexus

A stealthy game hub disguised as an educational platform.

## Getting Started

1. Unzip this folder.
2. Run \`npm install\`
3. Create a \`.env\` file with \`VITE_GEMINI_API_KEY=your_key_here\`
4. Run \`npm run dev\`

## Deployment

Push this repository to GitHub and connect it to Vercel or Netlify for instant deployment.
`);

  zip.file(".gitignore", `node_modules
dist
.env
.DS_Store
`);

  zip.file("index.html", `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Log in - Stile</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`);

  // 2. Source Code
  const src = zip.folder("src");

  // main.tsx (Entry point)
  src?.file("main.tsx", `import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
`);

  // index.css
  src?.file("index.css", `@tailwind base;
@tailwind components;
@tailwind utilities;

body {
  background-color: #0f0f1a;
  color: #eaeaea;
  overflow: hidden; 
}
/* Custom Scrollbar */
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}
::-webkit-scrollbar-track {
  background: #1a1a2e; 
}
::-webkit-scrollbar-thumb {
  background: #33334d; 
  border-radius: 4px;
}
::-webkit-scrollbar-thumb:hover {
  background: #00f3ff; 
}

/* Stealth Mode overrides */
body.stealth-mode {
  background-color: #ffffff;
  color: #172B4D;
}
body.stealth-mode ::-webkit-scrollbar-track {
  background: #eee;
}
body.stealth-mode ::-webkit-scrollbar-thumb {
  background: #ccc;
}
`);

  // types.ts
  src?.file("types.ts", `
export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  isStreaming?: boolean;
}

export interface GameConfig {
  id: string;
  title: string;
  url: string;
  description: string;
  category: 'Platformer' | 'Arcade' | 'Puzzle' | 'Strategy' | 'Endless' | 'RPG' | 'Racing' | 'Sports' | 'Entertainment';
  controls?: string;
  thumbnailUrl?: string;
}
`);

  // App.tsx
  src?.file("App.tsx", `
import React, { useState, useEffect } from 'react';
import GameEmbed from './components/GameEmbed';
import AiAssistant from './components/AiAssistant';
import StileDisguise from './components/StileDisguise';
import { GameConfig } from './types';

// Game Library Data
const GAMES: GameConfig[] = [
  {
    id: 'deltarune',
    title: "Deltarune (Scratch Edition)",
    url: "https://scratch.mit.edu/projects/1201842653/embed", 
    category: "RPG",
    description: "A fan-made recreation of the legendary RPG. Navigate the Dark World, dodge bullet patterns in fast-paced soul battles, and decide the fate of your enemies.",
    controls: "Arrow Keys to Move • Z to Interact/Select • X to Cancel/Menu",
    thumbnailUrl: "https://cdn2.scratch.mit.edu/get_image/project/1201842653_480x360.png"
  },
  {
    id: 'retro-bowl',
    title: "Game Hub",
    url: "https://retro-bowl-2.pages.dev/item?lesson=314",
    category: "Sports",
    description: "The glorious return of retro style football! Manage your NFL franchise, expand your roster, and take care of your press duties to keep your team and fans happy.",
    controls: "Mouse (Drag to Pass) • Click to Dive/Juke",
    thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400' style='background-color:black;'%3E%3Ctext x='290' y='230' font-family='Arial, Helvetica, sans-serif' font-weight='900' font-size='100' fill='white' text-anchor='end' letter-spacing='-4'%3EGame%3C/text%3E%3Crect x='305' y='145' width='190' height='120' rx='15' fill='%23ff9900' /%3E%3Ctext x='400' y='230' font-family='Arial, Helvetica, sans-serif' font-weight='900' font-size='100' fill='black' text-anchor='middle' letter-spacing='-4'%3Ehub%3C/text%3E%3C/svg%3E"
  },
  {
    id: 'pacman',
    title: "Pacman",
    url: "https://masonicgit.github.io/pacman/",
    category: "Arcade",
    description: "The timeless classic. Navigate the maze, eat all the pellets, avoid the ghosts (Blinky, Pinky, Inky, and Clyde), and chase the high score.",
    controls: "Arrow Keys to Move",
    thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='200' viewBox='0 0 600 200'%3E%3Crect width='600' height='200' rx='10' fill='%23ff9900' stroke='%23cc0000' stroke-width='15'/%3E%3Ctext x='300' y='140' font-family='Arial Black, Impact, sans-serif' font-weight='900' font-size='110' fill='%23ffff00' stroke='%23000000' stroke-width='6' text-anchor='middle' letter-spacing='2' style='filter: drop-shadow(5px 5px 0px rgba(0,0,0,0.5));'%3EPAC-MAN%3C/text%3E%3C/svg%3E"
  },
  {
    id: 'seraph',
    title: "Seraph",
    url: "https://mspoi.github.io/seraph/index.html",
    category: "Arcade",
    description: "A fast-paced rogue-like shooter. Play as a wizard, survive waves of enemies, and stack powerful upgrade cards to become unstoppable.",
    controls: "WASD to Move • Mouse to Aim & Shoot",
    thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400'%3E%3Cdefs%3E%3ClinearGradient id='grad1' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:%234b0082;stop-opacity:1' /%3E%3Cstop offset='100%25' style='stop-color:%23000000;stop-opacity:1' /%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='600' height='400' fill='url(%23grad1)' /%3E%3Ccircle cx='300' cy='200' r='80' fill='none' stroke='%2300ffff' stroke-width='4' /%3E%3Cpath d='M300 120 L300 280 M220 200 L380 200' stroke='%2300ffff' stroke-width='2' /%3E%3Ctext x='300' y='350' font-family='Courier New, monospace' font-weight='bold' font-size='40' fill='%2300ffff' text-anchor='middle' letter-spacing='5'%3ESERAPH%3C/text%3E%3C/svg%3E"
  },
  {
    id: 'ngon',
    title: "n-gon",
    url: "https://landgreen.github.io/n-gon/",
    category: "Arcade",
    description: "A fast-paced physics platformer. Wall-jump, slide, and shoot your way through procedurally generated levels as a polygon.",
    controls: "WASD/Arrows to Move • Mouse to Aim & Shoot",
    thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400'%3E%3Crect width='600' height='400' fill='%231a1a1a' /%3E%3Cpolygon points='300,80 490,190 420,380 180,380 110,190' fill='none' stroke='%23ff3333' stroke-width='15' /%3E%3Ctext x='300' y='240' font-family='Courier New, monospace' font-weight='bold' font-size='100' fill='white' text-anchor='middle'%3En-gon%3C/text%3E%3C/svg%3E"
  },
  {
    id: 'topvaz',
    title: "TopVAZ Games",
    url: "https://top-vaz-online.github.io/",
    category: "Arcade",
    description: "A massive collection of unblocked web games. Features classics like Basket Random, Pixel Shooter, and more.",
    controls: "Mouse to Browse • Various Controls",
    thumbnailUrl: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400'%3E%3Crect width='600' height='400' fill='%23111' /%3E%3Ctext x='50%25' y='50%25' font-family='Verdana' font-weight='bold' font-size='80' fill='white' text-anchor='middle' dy='.3em'%3ETOPVAZ%3C/text%3E%3Crect x='100' y='120' width='400' height='10' fill='%23e53935' /%3E%3C/svg%3E"
  }
];

const App: React.FC = () => {
  const [activeGame, setActiveGame] = useState<GameConfig | null>(null);
  const [isDisguised, setIsDisguised] = useState(true);

  // Toggle stealth mode class on body for scrollbar styling
  useEffect(() => {
    if (isDisguised) {
      document.body.classList.add('stealth-mode');
      document.title = "Log in - Stile";
    } else {
      document.body.classList.remove('stealth-mode');
      document.title = activeGame ? activeGame.title : "Arcade Nexus";
    }
  }, [isDisguised, activeGame]);

  if (isDisguised) {
    return <StileDisguise onUnlock={() => setIsDisguised(false)} />;
  }

  return (
    <div className="flex h-screen w-full bg-arcade-dark text-arcade-text font-sans overflow-hidden">
      {/* Sidebar Game List */}
      <div className="w-20 md:w-64 flex-shrink-0 bg-arcade-panel border-r border-white/10 flex flex-col z-20">
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <h1 className="text-xl font-bold text-arcade-neon tracking-tighter hidden md:block">
            NEXUS
          </h1>
          {/* Panic Button */}
          <button 
            onClick={() => setIsDisguised(true)}
            className="p-2 bg-red-500/20 text-red-400 rounded hover:bg-red-500/40 transition-colors"
            title="Panic Exit (Return to Stile)"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" />
            </svg>
          </button>
        </div>
        
        <div className="flex-grow overflow-y-auto p-2 space-y-2">
          {/* Home / Gallery Button */}
          <button
            onClick={() => setActiveGame(null)}
            className={\`w-full flex items-center gap-3 p-3 rounded-lg transition-all duration-200 \${
              !activeGame 
                ? 'bg-arcade-neon/20 text-arcade-neon shadow-[0_0_10px_rgba(0,243,255,0.1)]' 
                : 'hover:bg-white/5 text-gray-400 hover:text-white'
            }\`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25a2.25 2.25 0 01-2.25-2.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z" />
            </svg>
            <span className="hidden md:block font-medium">Gallery</span>
          </button>

          <div className="h-px bg-white/10 my-2 mx-2" />

          {/* Game List */}
          {GAMES.map((game) => (
            <button
              key={game.id}
              onClick={() => setActiveGame(game)}
              className={\`w-full flex items-center gap-3 p-3 rounded-lg text-left transition-all duration-200 group relative overflow-hidden \${
                activeGame?.id === game.id 
                  ? 'bg-arcade-neon text-black font-bold shadow-[0_0_15px_rgba(0,243,255,0.4)]' 
                  : 'hover:bg-white/10 text-gray-300 hover:text-white'
              }\`}
            >
              {/* Active Indicator */}
              {activeGame?.id === game.id && (
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-white animate-pulse" />
              )}
              
              <div className="w-8 h-8 rounded bg-black/50 flex-shrink-0 overflow-hidden border border-white/10">
                {game.thumbnailUrl ? (
                   <img src={game.thumbnailUrl} alt="" className="w-full h-full object-cover" />
                ) : (
                   <div className="w-full h-full flex items-center justify-center text-[10px] text-white/50">IMG</div>
                )}
              </div>
              <div className="hidden md:block truncate">
                <div className="text-sm truncate">{game.title}</div>
                <div className={\`text-[10px] uppercase tracking-wider \${activeGame?.id === game.id ? 'text-black/60' : 'text-white/30'}\`}>
                  {game.category}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-grow flex flex-col relative z-10 bg-arcade-dark">
        {activeGame ? (
          <GameEmbed config={activeGame} />
        ) : (
          /* Game Gallery View */
          <div className="flex-grow overflow-y-auto p-6 md:p-10">
            <header className="mb-10">
              <h1 className="text-4xl md:text-5xl font-black text-white mb-2 tracking-tighter">
                ARCADE <span className="text-arcade-neon text-transparent bg-clip-text bg-gradient-to-r from-arcade-neon to-arcade-pink">NEXUS</span>
              </h1>
              <p className="text-white/50 text-lg">Select a protocol to initiate.</p>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {GAMES.map((game) => (
                <div 
                  key={game.id}
                  onClick={() => setActiveGame(game)}
                  className="group relative h-64 bg-arcade-panel rounded-xl overflow-hidden border border-white/5 hover:border-arcade-neon/50 transition-all duration-300 cursor-pointer hover:shadow-[0_0_30px_rgba(0,243,255,0.15)] transform hover:-translate-y-1"
                >
                  {/* Background Image/Thumbnail */}
                  {game.thumbnailUrl && (
                    <div className="absolute inset-0">
                      <img 
                        src={game.thumbnailUrl} 
                        alt={game.title} 
                        className="w-full h-full object-cover opacity-60 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-arcade-panel via-arcade-panel/80 to-transparent opacity-90 group-hover:opacity-60 transition-opacity duration-300" />
                    </div>
                  )}

                  <div className="absolute inset-0 p-6 flex flex-col justify-end">
                    <div className="transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                      <div className="flex items-center gap-2 mb-2">
                         <span className="px-2 py-1 rounded text-[10px] font-bold uppercase tracking-widest bg-arcade-neon/10 text-arcade-neon border border-arcade-neon/20 backdrop-blur-sm">
                          {game.category}
                        </span>
                      </div>
                      <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-arcade-neon transition-colors">
                        {game.title}
                      </h3>
                      <p className="text-sm text-gray-400 line-clamp-2 mb-4 group-hover:text-white transition-colors">
                        {game.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* AI Assistant Panel */}
      <AiAssistant activeGameTitle={activeGame?.title || 'Main Menu'} />
    </div>
  );
};

export default App;
`);

  // Components Folder
  const components = src?.folder("components");
  
  components?.file("GameEmbed.tsx", `import React, { useRef, useState, useEffect } from 'react';
import { GameConfig } from '../types';

interface GameEmbedProps {
  config: GameConfig;
}

const GameEmbed: React.FC<GameEmbedProps> = ({ config }) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      const container = document.getElementById('game-container');
      if (container) {
        container.requestFullscreen().catch(err => {
          console.error(\`Error attempting to enable fullscreen: \${err.message}\`);
        });
      }
    } else {
      document.exitFullscreen();
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // Focus iframe on mount so keyboard controls work immediately
  useEffect(() => {
    if (iframeRef.current) {
      iframeRef.current.focus();
    }
  }, []);

  const handleRefocus = () => {
    if(iframeRef.current) {
      iframeRef.current.focus();
    }
  };

  return (
    <div 
      id="game-container" 
      className={\`relative w-full h-full bg-black flex flex-col \${isFullscreen ? 'p-0' : 'rounded-lg border-2 border-arcade-panel shadow-[0_0_15px_rgba(0,243,255,0.2)]'}\`}
    >
      {/* Header / Controls Bar (Hidden in Fullscreen) */}
      {!isFullscreen && (
        <div className="flex justify-between items-center p-3 bg-arcade-panel border-b border-white/10">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></div>
            <h2 className="text-arcade-neon font-bold tracking-wider uppercase text-sm md:text-base">
              {config.title}
            </h2>
          </div>
          <div className="flex items-center space-x-2">
             <a 
              href={config.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-3 py-1 text-xs bg-arcade-neon/10 hover:bg-arcade-neon/30 text-arcade-neon border border-arcade-neon/20 rounded transition-colors"
              title="Open in new tab if game doesn't load"
            >
              Open External
            </a>
             <button 
              onClick={handleRefocus}
              className="px-3 py-1 text-xs bg-white/10 hover:bg-white/20 text-white rounded transition-colors"
              title="Click if controls aren't working"
            >
              Focus Game
            </button>
            <button 
              onClick={toggleFullscreen}
              className="p-1 hover:text-arcade-neon transition-colors"
              aria-label="Toggle Fullscreen"
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* The Game Iframe */}
      <div className="flex-grow relative overflow-hidden bg-black">
        <iframe
          ref={iframeRef}
          src={config.url}
          title={config.title}
          className="absolute top-0 left-0 w-full h-full border-0"
          allow="autoplay; fullscreen; gamepad; clipboard-read; clipboard-write"
          allowFullScreen
          sandbox="allow-scripts allow-same-origin allow-forms allow-pointer-lock allow-presentation allow-modals allow-popups"
        />
      </div>
    </div>
  );
};

export default GameEmbed;`);

  components?.file("AiAssistant.tsx", `import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { streamGameTips } from '../services/geminiService';

interface AiAssistantProps {
  activeGameTitle: string;
}

const AiAssistant: React.FC<AiAssistantProps> = ({ activeGameTitle }) => {
  const [isOpen, setIsOpen] = useState(true);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: \`Hello! I'm Gemini. I can help you with \${activeGameTitle} strategies or answer any other questions you have.\`,
    }
  ]);
  
  const prevGameRef = useRef(activeGameTitle);

  useEffect(() => {
    if (prevGameRef.current !== activeGameTitle) {
      setMessages(prev => [
        ...prev,
        {
          id: Date.now().toString(),
          role: 'model',
          text: \`✨ Context updated: Now focusing on \${activeGameTitle}.\`
        }
      ]);
      prevGameRef.current = activeGameTitle;
    }
  }, [activeGameTitle]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    const history = messages.map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));

    try {
      const stream = streamGameTips(history, userMsg.text, activeGameTitle);
      
      const modelMsgId = (Date.now() + 1).toString();
      setMessages(prev => [...prev, {
        id: modelMsgId,
        role: 'model',
        text: '',
        isStreaming: true
      }]);

      let fullText = '';
      for await (const chunk of stream) {
        fullText += chunk;
        setMessages(prev => prev.map(msg => 
          msg.id === modelMsgId ? { ...msg, text: fullText } : msg
        ));
      }

      setMessages(prev => prev.map(msg => 
        msg.id === modelMsgId ? { ...msg, isStreaming: false } : msg
      ));

    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={\`
      flex flex-col bg-arcade-panel border-l border-white/10 transition-all duration-300 ease-in-out
      \${isOpen ? 'w-full md:w-80 lg:w-96' : 'w-12'}
      h-full relative
    \`}>
      
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="absolute -left-3 top-1/2 transform -translate-y-1/2 bg-blue-500 text-white p-1 rounded-full shadow-lg z-10 hover:bg-blue-400 transition-colors"
      >
        {isOpen ? (
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-4 h-4">
            <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
          </svg>
        ) : (
           <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-4 h-4">
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
          </svg>
        )}
      </button>

      {!isOpen && (
        <div className="h-full flex items-center justify-center cursor-pointer" onClick={() => setIsOpen(true)}>
          <span className="transform -rotate-90 whitespace-nowrap text-blue-400 font-bold tracking-widest text-sm">
            GEMINI
          </span>
        </div>
      )}

      <div className={\`flex flex-col h-full \${!isOpen ? 'hidden' : 'block'}\`}>
        <div className="p-4 border-b border-white/10 bg-black/20">
          <h3 className="text-blue-400 font-bold text-lg flex items-center gap-2">
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 animate-pulse">
                <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
            </svg>
            GEMINI
          </h3>
          <p className="text-xs text-white/50 truncate">Active Context: {activeGameTitle}</p>
        </div>

        <div className="flex-grow overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className={\`flex \${msg.role === 'user' ? 'justify-end' : 'justify-start'}\`}>
              <div 
                className={\`
                  max-w-[85%] p-3 rounded-lg text-sm leading-relaxed
                  \${msg.role === 'user' 
                    ? 'bg-blue-600 text-white rounded-tr-none font-medium' 
                    : 'bg-white/10 text-gray-200 rounded-tl-none border border-white/5'
                  }
                \`}
              >
                {msg.text}
                {msg.isStreaming && <span className="inline-block w-1.5 h-3 ml-1 bg-blue-400 animate-pulse"/>}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 bg-black/20 border-t border-white/10">
          <form onSubmit={handleSend} className="relative">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={\`Ask Gemini...\`}
              disabled={isLoading}
              className="w-full bg-black/50 border border-white/20 rounded-full py-2 pl-4 pr-10 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="absolute right-1 top-1/2 transform -translate-y-1/2 p-1.5 bg-blue-600 rounded-full text-white hover:bg-blue-500 disabled:opacity-50 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
                <path d="M3.105 2.289a.75.75 0 00-.826.95l1.414 4.925A1.5 1.5 0 005.135 9.25h6.115a.75.75 0 010 1.5H5.135a1.5 1.5 0 00-1.442 1.086l-1.414 4.926a.75.75 0 00.826.95 28.896 28.896 0 0015.293-7.154.75.75 0 000-1.115A28.897 28.897 0 003.105 2.289z" />
              </svg>
            </button>
          </form>
          <div className="flex gap-2 mt-2 justify-center">
            <button onClick={() => setInput("How do I play?")} className="text-[10px] px-2 py-1 bg-white/5 rounded hover:bg-white/10 text-gray-400">Controls?</button>
            <button onClick={() => setInput("Help me with my homework")} className="text-[10px] px-2 py-1 bg-white/5 rounded hover:bg-white/10 text-gray-400">Homework Help</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AiAssistant;`);

  components?.file("StileDisguise.tsx", `import React, { useState } from 'react';

interface StileDisguiseProps {
  onUnlock: () => void;
}

const StileDisguise: React.FC<StileDisguiseProps> = ({ onUnlock }) => {
  const [email, setEmail] = useState('');

  const handleFakeAction = () => {
    // Fake behavior: Refresh the page to simulate a "glitch" or login loop
    window.location.reload();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleFakeAction();
  };

  // Lighter Green for Stile as requested
  const STILE_GREEN = "#00C985";

  return (
    <div className="min-h-screen bg-white flex flex-col font-sans text-[#172B4D]">
      
      {/* Navbar / Header */}
      <header className="px-8 py-6">
        <div 
          className={\`font-bold text-3xl tracking-tighter select-none cursor-default\`}
          style={{ color: STILE_GREEN }}
        >
          stile
        </div>
      </header>

      {/* Login Container */}
      <div className="flex-grow flex items-center justify-center p-4">
        <div className="w-full max-w-[480px]">
          
          <h1 className="text-4xl font-bold mb-3 text-[#172B4D]">Log in</h1>
          <p className="text-gray-600 mb-8 text-lg">
            Don't have an account? <span onClick={handleFakeAction} className="hover:underline cursor-pointer" style={{ color: STILE_GREEN }}>Sign up</span>
          </p>

          {/* Social Logins */}
          <div className="space-y-3 mb-8">
            <button type="button" onClick={handleFakeAction} className="w-full border border-gray-300 rounded-md py-2.5 px-4 flex items-center justify-center gap-3 hover:bg-gray-50 transition-colors font-medium text-gray-700">
               <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 23 23"><path fill="#f3f3f3" d="M0 0h23v23H0z"/><path fill="#f35325" d="M1 1h10v10H1z"/><path fill="#81bc06" d="M12 1h10v10H12z"/><path fill="#05a6f0" d="M1 12h10v10H1z"/><path fill="#ffba08" d="M12 12h10v10H12z"/></svg>
               Sign in with Microsoft
            </button>
            <button type="button" onClick={handleFakeAction} className="w-full border border-gray-300 rounded-md py-2.5 px-4 flex items-center justify-center gap-3 hover:bg-gray-50 transition-colors font-medium text-gray-700">
               <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12c0-6.627 5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C12.955 4 4 12.955 4 24c0 11.045 8.955 20 20 20c11.045 0 20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"/><path fill="#FF3D00" d="m6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4c-7.865 0-14.739 4.316-18.232 10.691z"/><path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238C29.211 35.091 26.715 36 24 36c-5.202 0-9.619-3.317-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z"/><path fill="#1976D2" d="M43.611 20.083L43.595 20H24v8h11.303a12.04 12.04 0 0 1-4.087 5.571l.003-.002l6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z"/></svg>
               Sign in with Google
            </button>
          </div>

          <div className="relative mb-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500 font-medium">OR</span>
            </div>
          </div>

          {/* Email Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Email</label>
              <input 
                type="text" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={\`w-full px-4 py-3 rounded border border-gray-300 focus:ring-1 outline-none transition-colors text-lg\`}
                style={{ 
                  '--tw-ring-color': STILE_GREEN, 
                  '--tw-border-opacity': 1,
                  borderColor: email ? STILE_GREEN : undefined 
                } as React.CSSProperties}
                placeholder=""
                autoFocus
              />
            </div>
            
            <div className="flex justify-end">
               <button 
                 type="submit" 
                 className="hover:brightness-90 text-white font-bold py-3 px-6 rounded transition-all flex items-center gap-2"
                 style={{ backgroundColor: STILE_GREEN }}
               >
                 Next
                 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={3} stroke="currentColor" className="w-4 h-4">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                </svg>
               </button>
            </div>
          </form>

        </div>
      </div>

      {/* Footer */}
      <footer className="py-8 text-center text-sm text-gray-500">
         <span 
          onClick={onUnlock} 
          className="mr-6 hover:underline cursor-pointer"
          title="Privacy Policy"
         >
            Privacy Policy
         </span>
         <span 
          onClick={handleFakeAction} 
          className="hover:underline cursor-pointer"
        >
           Terms & Conditions
        </span>
      </footer>

    </div>
  );
};

export default StileDisguise;`);

  // Services
  const services = src?.folder("services");
  services?.file("geminiService.ts", `import { GoogleGenAI } from "@google/genai";

// NOTE: In a real Vite app, use import.meta.env.VITE_GEMINI_API_KEY
// The key is injected via process.env in the web container but needs to be handled via env vars in the downloaded repo.
const apiKey = import.meta.env.VITE_GEMINI_API_KEY || process.env.API_KEY; 

const ai = new GoogleGenAI({ apiKey: apiKey || 'INSERT_API_KEY_HERE' });

const getSystemInstruction = (gameTitle: string) => \`
You are Gemini, a helpful and intelligent AI assistant.
The user is currently playing: "\${gameTitle}".
Your goal is to help the user with anything they need, whether it's specific strategies for the game they are playing, homework help, or general conversation.

- Context: The user is likely at school or work, using this app which is disguised as an educational tool.
- Tone: Friendly, helpful, concise, and smart.
- Game Help: If asked about \${gameTitle}, provide specific tips (mechanics, controls, strategies).
- General Help: If asked about other topics (math, science, writing), provide excellent educational assistance.
\`;

export const streamGameTips = async function* (
  history: { role: string; parts: { text: string }[] }[],
  newMessage: string,
  gameTitle: string
) {
  try {
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: getSystemInstruction(gameTitle),
        thinkingConfig: { thinkingBudget: 0 },
      },
      history: history,
    });

    const result = await chat.sendMessageStream({ message: newMessage });

    for await (const chunk of result) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    yield "⚠️ Connection interference. Try again or check your API Key in .env";
  }
};
`);

  // Generate the zip
  const content = await zip.generateAsync({ type: "blob" });
  
  // Trigger download
  const url = URL.createObjectURL(content);
  const a = document.createElement("a");
  a.href = url;
  a.download = "arcade-nexus-source.zip";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};
